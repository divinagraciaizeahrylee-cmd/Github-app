---
name: SkyWalk Atmospheric System
colors:
  surface: '#0c131f'
  surface-dim: '#0c131f'
  surface-bright: '#323947'
  surface-container-lowest: '#070e1a'
  surface-container-low: '#151c28'
  surface-container: '#19202c'
  surface-container-high: '#232a37'
  surface-container-highest: '#2e3542'
  on-surface: '#dce2f4'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dce2f4'
  inverse-on-surface: '#2a313e'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#ff7886'
  on-tertiary-container: '#780021'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#0c131f'
  on-background: '#dce2f4'
  surface-variant: '#2e3542'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  metric-huge:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  metric-huge-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style
The design system powers an hourly outdoor walkability and atmospheric intelligence platform. Its primary audience comprises urban walkers, endurance runners, pet owners, and outdoor professionals who need unambiguous, split-second meteorological clarity before stepping outside.

The visual direction combines **atmospheric glassmorphism** with **aerospace-grade instrumentation**. Deep, near-space slate tones form an infinite canvas that recedes into the background, allowing luminous condition indicators to command attention without visual noise. Surfaces simulate micro-frosted aerospace glass: clean specular highlights, whisper-thin ambient light rims, and deep backdrop diffusion. The emotional profile is authoritative, serene, and hyper-vigilant—instilling confidence through scientific consensus rather than generic weather iconography.

## Colors
The palette is rooted in absolute nighttime and deep-troposphere hues, ensuring maximum luminance separation for critical environmental safety tiers:

- **Canvas & Surface Foundation**:
  - Deep Space Canvas: `#0C131F`
  - Atmospheric Layer 1 (Surface Elevate): `#131D2E`
  - Atmospheric Layer 2 (Elevated Panels): `#1A263C`
  - Card Stroke / Horizon Rim: `rgba(255, 255, 255, 0.08)`
  - Active Stroke Highlight: `rgba(255, 255, 255, 0.18)`

- **Walkability Safety Status**:
  - **Optimal / Safe**: `#10B981` (Emerald Green) — Indicates ideal barometric pressure, prime air quality index, and benign wind vectors.
  - **Caution / Shift**: `#F59E0B` (Golden Amber) — Highlights impending gusts, high UV indices, or volatile frontal movement.
  - **Severe / Warning**: `#F43F5E` (Crimson Coral) — Flags active precipitation cells, cloud-to-ground lightning risk, or dangerous wind chills.

- **Atmospheric Accents & Consensus**:
  - Cyan Data Stream: `#38BDF8` — Reserved for humidity, dew points, and precipitation volume metrics.
  - Station Consensus Neutral: `#94A3B8` — Used for meteorological source labels (NOAA, ECMWF, MetOffice).

All status colors must meet WCAG AAA contrast targets against `#0C131F` and `#131D2E`. Never use the primary green as a decorative ambient wash; status hues carry explicit, functional safety meaning.

## Typography
The typographic architecture relies on three deliberate type engines:

1. **Space Grotesk (Headlines & Big Metrics)**: Imparts structural, modern, geometric character suitable for meteorological instrument dashboards.
2. **Hanken Grotesk (Body & Structural Copy)**: Delivers neutral, highly legible reading experiences under outdoor glare and rapid scrolling.
3. **JetBrains Mono (Telemetry, Model Consensus, Timestamps)**: Fixes glyph widths to prevent layout jitter as numerical values update live; conveys precision scientific telemetry.

All dynamic numerical units (°C/°F, km/h, hPa, UV) render with `font-variant-numeric: tabular-nums lining-nums`.

## Layout & Spacing
The layout follows a fluid 12-column responsive layout built to handle wide radar canvases, multi-source model comparisons, and dense hourly horizontal timelines.

- **Mobile (< 768px)**: 4-column system. Margins fixed to `1rem` (`16px`) to maximize screen estate for timeline charts. Hourly scrubbers scroll horizontally along the viewport edge with snapping intervals.
- **Tablet (768px – 1024px)**: 8-column system with `2rem` margins. Two-column split: Primary safety indicator and forecast on the left (5 cols), detailed weather matrices and telemetry on the right (3 cols).
- **Desktop (> 1024px)**: 12-column grid capped at a maximum width of `1440px`. Gutters sit at `1.5rem` (`24px`). Provides a three-tier dashboard: Hero walkability timeline (8 cols), consensus telemetry panel (4 cols), and full-width multi-hour weather matrices beneath.

Spacing rhythm strictly adheres to a 4px/8px modular base. Metric cards use internal padding of `space-md` (`16px`) on mobile and `space-lg` (`24px`) on desktop.

## Elevation & Depth
Elevation is realized through frosted glass layering, atmospheric occlusion, and luminous back-glows rather than traditional drop shadows:

- **Level 0 (Atmospheric Bed)**: Background `#0C131F` with a subtle top-center radial gradient of `radial-gradient(ellipse at 50% -10%, rgba(56, 189, 248, 0.08), transparent 70%)`.
- **Level 1 (Telemetry Panels & Secondary Surfaces)**: Solid `#131D2E` at 85% opacity, `backdrop-filter: blur(16px)`, finished with a crisp hairline stroke `1px solid rgba(255, 255, 255, 0.07)`.
- **Level 2 (Active Walkability Cards & Modal Overlays)**: Surface `#1A263C` at 70% opacity, `backdrop-filter: blur(24px) saturate(180%)`, bordered by `1px solid rgba(255, 255, 255, 0.12)`.
- **Safety Glow Accents**:
  - *Optimal*: Soft directional underglow: `0 8px 32px -4px rgba(16, 185, 129, 0.22)`.
  - *Caution*: Soft directional underglow: `0 8px 32px -4px rgba(245, 158, 11, 0.22)`.
  - *Severe*: Pulsing directional underglow: `0 8px 32px -4px rgba(244, 63, 94, 0.28)`.

No pure black shadows are permitted. All depth shadows use tinted slate-navy mixes (`rgba(4, 9, 16, 0.45)` to `rgba(4, 9, 16, 0.75)`).

## Shapes
The shape language uses `roundedness: 2`, delivering a calibrated balance between structural engineering precision and ergonomic touch handling.

- **Primary Cards and Panels**: `1rem` (`16px`) corner radius (`rounded-lg`).
- **Telemetry Chips, Badges, and Pill Toggles**: Fully pill-shaped (`9999px`) to visually signal self-contained atomic data tokens (e.g., station sources, wind direction pills).
- **Sub-module Tiles (Inside Cards)**: `0.5rem` (`8px`) corner radius.
- **Buttons and Scrubber Thumb Grips**: `0.75rem` (`12px`) corner radius for confident tactile interaction.

## Components

### Buttons & Interactive Triggers
- **Primary Action (e.g., 'Plan Walk Window')**: Fill is dynamic based on current forecast safety index (defaulting to `#10B981` during optimal windows). Label in bold Space Grotesk, dark text `#0C131F` for maximum legibility. Hover yields slight luminescence scale `box-shadow: 0 0 20px rgba(16, 185, 129, 0.4)`.
- **Ghost/Instrument Buttons**: Transparent body with `1px solid rgba(255, 255, 255, 0.12)`, text in `#F8FAFC`. On hover, background shifts to `rgba(255, 255, 255, 0.05)` with `rgba(255, 255, 255, 0.24)` border.

### Walkability Hourly Cards
- Contained horizontal glass panels. Active selected hour displays a top accent bar (2px height) matched to the safety state color (`#10B981`, `#F59E0B`, or `#F43F5E`).
- Interior metrics display time (`label-code`), weather glyph, temperature (`metric-md`), and wind vector arrow with exact velocity notation.

### Meteorological Station Consensus Badges
- Pill-shaped badges aggregating NOAA (GFS/HRRR), ECMWF, and MetOffice readings.
- Height: `24px`. Background: `rgba(255, 255, 255, 0.04)`. Border: `1px solid rgba(255, 255, 255, 0.08)`.
- Features an indicator dot: green (90%+ model convergence), amber (divergent precipitation timing), or red (active conflicting high-impact models). Text set in `JetBrains Mono` at `11px`.

### Telemetry Tiles & Data Lists
- Structured two-column or four-column matrix cards for Barometer, Dew Point, Cloud Ceiling, UV Index, and Wind Gusts.
- Label positioned at top in uppercase `label-caps` with `#94A3B8`. Primary numerical metric set in `metric-md` or `Space Grotesk 20px` in `#F8FAFC`.

### Form Inputs & Search Bar
- Location Search Bar: Recessed pill or `rounded-lg` container with background `#131D2E`, inset hairline border `1px solid rgba(255, 255, 255, 0.1)`. Focus state creates a localized cyan halo `box-shadow: 0 0 0 2px rgba(56, 189, 248, 0.35)`.

### Toggles & Segmented Controls
- Segmented switch (e.g., switching between "Walk Score", "Wind Chill", "Precipitation"): Encased inside a `rgba(255, 255, 255, 0.04)` pill track. Active pill slides with a fluid spring curve, surfaced in `#1E2B42` with crisp text `#FFFFFF`.